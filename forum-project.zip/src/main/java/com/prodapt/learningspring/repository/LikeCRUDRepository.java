package com.prodapt.learningspring.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.prodapt.learningspring.entity.LikeId;
import com.prodapt.learningspring.entity.LikeRecord;
import com.prodapt.learningspring.entity.Post;
import com.prodapt.learningspring.entity.User;

public interface LikeCRUDRepository extends CrudRepository<LikeRecord, LikeId>{
	  public Integer countByLikeIdPost(Post post);
	  
	  @Query(value = "SELECT * FROM LikeRecord l WHERE l.likeId.user_id = ?1 AND l.likeId.post_id = ?2")
	  public LikeRecord findByLikeIdUserAndLikeIdPost(long userId, long postId);
}
